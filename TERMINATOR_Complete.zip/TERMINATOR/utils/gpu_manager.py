"""
Multi-GPU Manager
=================

Gestión de múltiples GPUs para inferencia distribuida.
"""

import torch
import torch.distributed as dist
from torch.nn.parallel import DataParallel, DistributedDataParallel
import logging
from typing import List, Optional, Dict, Any
import os
import subprocess

logger = logging.getLogger(__name__)


class GPUManager:
    """Gestor de GPUs para entrenamiento e inferencia"""
    
    def __init__(
        self,
        device_ids: Optional[List[int]] = None,
        strategy: str = "data_parallel",
        memory_fraction: float = 0.9
    ):
        self.device_ids = device_ids or self._get_available_gpus()
        self.strategy = strategy
        self.memory_fraction = memory_fraction
        self.num_gpus = len(self.device_ids)
        
        # Configurar GPUs
        self._setup_gpus()
        
        logger.info(f"GPU Manager inicializado con {self.num_gpus} GPUs")
        logger.info(f"Estrategia: {self.strategy}")
    
    def _get_available_gpus(self) -> List[int]:
        """Detecta GPUs disponibles"""
        if not torch.cuda.is_available():
            logger.warning("CUDA no disponible")
            return []
        
        num_gpus = torch.cuda.device_count()
        logger.info(f"Detectadas {num_gpus} GPUs")
        
        return list(range(num_gpus))
    
    def _setup_gpus(self):
        """Configura GPUs"""
        if not self.device_ids:
            return
        
        # Configurar memoria
        for device_id in self.device_ids:
            torch.cuda.set_per_process_memory_fraction(
                self.memory_fraction,
                device=device_id
            )
        
        # Configurar device principal
        if self.device_ids:
            torch.cuda.set_device(self.device_ids[0])
    
    def get_device(self, index: int = 0) -> torch.device:
        """Obtiene un device específico"""
        if not self.device_ids:
            return torch.device("cpu")
        
        device_id = self.device_ids[index % self.num_gpus]
        return torch.device(f"cuda:{device_id}")
    
    def parallelize_model(self, model: torch.nn.Module) -> torch.nn.Module:
        """
        Paraleliza un modelo según la estrategia configurada
        
        Args:
            model: Modelo a paralelizar
        
        Returns:
            Modelo paralelizado
        """
        if not self.device_ids or self.num_gpus == 1:
            # Sin paralelización
            device = self.get_device(0)
            return model.to(device)
        
        if self.strategy == "data_parallel":
            return self._data_parallel(model)
        elif self.strategy == "model_parallel":
            return self._model_parallel(model)
        elif self.strategy == "pipeline":
            return self._pipeline_parallel(model)
        else:
            logger.warning(f"Estrategia '{self.strategy}' no reconocida, usando data_parallel")
            return self._data_parallel(model)
    
    def _data_parallel(self, model: torch.nn.Module) -> torch.nn.Module:
        """Paralelización de datos"""
        logger.info("Aplicando Data Parallel")
        
        device = self.get_device(0)
        model = model.to(device)
        
        if self.num_gpus > 1:
            model = DataParallel(model, device_ids=self.device_ids)
        
        return model
    
    def _model_parallel(self, model: torch.nn.Module) -> torch.nn.Module:
        """Paralelización de modelo"""
        logger.info("Aplicando Model Parallel")
        
        # Dividir modelo entre GPUs
        if hasattr(model, 'transformer'):
            layers = model.transformer.h
        elif hasattr(model, 'model'):
            layers = model.model.layers
        else:
            logger.warning("No se pudo aplicar model parallel, usando data parallel")
            return self._data_parallel(model)
        
        # Distribuir capas entre GPUs
        layers_per_gpu = len(layers) // self.num_gpus
        
        for i, layer in enumerate(layers):
            gpu_id = min(i // layers_per_gpu, self.num_gpus - 1)
            device = self.get_device(gpu_id)
            layer.to(device)
        
        return model
    
    def _pipeline_parallel(self, model: torch.nn.Module) -> torch.nn.Module:
        """Paralelización por pipeline"""
        logger.info("Aplicando Pipeline Parallel")
        
        # Implementación simplificada
        # En producción, usarías torch.distributed.pipeline
        
        return self._model_parallel(model)
    
    def get_gpu_info(self) -> Dict[int, Dict[str, Any]]:
        """Obtiene información de todas las GPUs"""
        info = {}
        
        for device_id in self.device_ids:
            props = torch.cuda.get_device_properties(device_id)
            
            info[device_id] = {
                'name': props.name,
                'total_memory': props.total_memory / 1024**3,  # GB
                'major': props.major,
                'minor': props.minor,
                'multi_processor_count': props.multi_processor_count,
            }
            
            # Memoria actual
            if torch.cuda.is_available():
                info[device_id]['allocated_memory'] = torch.cuda.memory_allocated(device_id) / 1024**3
                info[device_id]['cached_memory'] = torch.cuda.memory_reserved(device_id) / 1024**3
        
        return info
    
    def print_gpu_info(self):
        """Imprime información de GPUs"""
        info = self.get_gpu_info()
        
        print("\n" + "=" * 70)
        print("GPU INFORMATION")
        print("=" * 70)
        
        for device_id, gpu_info in info.items():
            print(f"\nGPU {device_id}: {gpu_info['name']}")
            print(f"  Total Memory: {gpu_info['total_memory']:.2f} GB")
            print(f"  Allocated: {gpu_info.get('allocated_memory', 0):.2f} GB")
            print(f"  Cached: {gpu_info.get('cached_memory', 0):.2f} GB")
            print(f"  Compute Capability: {gpu_info['major']}.{gpu_info['minor']}")
            print(f"  Multiprocessors: {gpu_info['multi_processor_count']}")
        
        print("\n" + "=" * 70)
    
    def clear_cache(self):
        """Limpia cache de GPUs"""
        if torch.cuda.is_available():
            torch.cuda.empty_cache()
            logger.info("Cache de GPU limpiado")
    
    def synchronize(self):
        """Sincroniza todas las GPUs"""
        if torch.cuda.is_available():
            torch.cuda.synchronize()


class NVMeModelLoader:
    """Cargador de modelos desde discos NVMe"""
    
    def __init__(self, nvme_paths: List[str]):
        self.nvme_paths = nvme_paths
        self.model_registry = {}
        
        logger.info(f"NVMe Loader inicializado con {len(nvme_paths)} paths")
    
    def register_model(
        self,
        model_name: str,
        model_path: str,
        nvme_index: int = 0
    ):
        """Registra un modelo en un disco NVMe específico"""
        if nvme_index >= len(self.nvme_paths):
            raise ValueError(f"NVMe index {nvme_index} fuera de rango")
        
        full_path = os.path.join(self.nvme_paths[nvme_index], model_path)
        
        self.model_registry[model_name] = {
            'path': full_path,
            'nvme_index': nvme_index,
            'loaded': False
        }
        
        logger.info(f"Modelo '{model_name}' registrado en NVMe {nvme_index}")
    
    def load_model(
        self,
        model_name: str,
        device: Optional[torch.device] = None
    ) -> Any:
        """Carga un modelo desde NVMe"""
        if model_name not in self.model_registry:
            raise ValueError(f"Modelo '{model_name}' no registrado")
        
        model_info = self.model_registry[model_name]
        model_path = model_info['path']
        
        logger.info(f"Cargando modelo '{model_name}' desde {model_path}")
        
        try:
            # Cargar modelo
            if model_path.endswith('.safetensors'):
                # Usar safetensors
                from safetensors.torch import load_file
                state_dict = load_file(model_path)
            else:
                # Usar torch
                state_dict = torch.load(model_path, map_location=device)
            
            model_info['loaded'] = True
            
            return state_dict
        
        except Exception as e:
            logger.error(f"Error cargando modelo: {e}")
            raise
    
    def get_model_info(self, model_name: str) -> Dict:
        """Obtiene información de un modelo"""
        if model_name not in self.model_registry:
            raise ValueError(f"Modelo '{model_name}' no registrado")
        
        return self.model_registry[model_name]
    
    def list_models(self) -> List[str]:
        """Lista todos los modelos registrados"""
        return list(self.model_registry.keys())


class DistributedManager:
    """Gestor para entrenamiento distribuido"""
    
    def __init__(
        self,
        backend: str = "nccl",
        init_method: str = "env://"
    ):
        self.backend = backend
        self.init_method = init_method
        self.initialized = False
    
    def setup(self, rank: int, world_size: int):
        """Inicializa proceso distribuido"""
        os.environ['MASTER_ADDR'] = os.getenv('MASTER_ADDR', 'localhost')
        os.environ['MASTER_PORT'] = os.getenv('MASTER_PORT', '12355')
        
        dist.init_process_group(
            backend=self.backend,
            init_method=self.init_method,
            rank=rank,
            world_size=world_size
        )
        
        self.initialized = True
        logger.info(f"Proceso distribuido inicializado: rank={rank}, world_size={world_size}")
    
    def cleanup(self):
        """Limpia proceso distribuido"""
        if self.initialized:
            dist.destroy_process_group()
            self.initialized = False
    
    def wrap_model(self, model: torch.nn.Module, device_id: int) -> torch.nn.Module:
        """Envuelve modelo para entrenamiento distribuido"""
        if not self.initialized:
            raise RuntimeError("Proceso distribuido no inicializado")
        
        model = model.to(device_id)
        model = DistributedDataParallel(model, device_ids=[device_id])
        
        return model


# Ejemplo de uso
if __name__ == "__main__":
    print("=" * 70)
    print("GPU MANAGER - EJEMPLO")
    print("=" * 70)
    
    # Crear manager
    gpu_manager = GPUManager()
    
    # Mostrar información
    gpu_manager.print_gpu_info()
    
    # Crear modelo de ejemplo
    print("\n📦 Creando modelo de ejemplo...")
    model = torch.nn.Linear(100, 10)
    
    # Paralelizar
    print("\n⚡ Paralelizando modelo...")
    model = gpu_manager.parallelize_model(model)
    
    print(f"\nModelo en device: {next(model.parameters()).device}")
    
    # NVMe Loader
    print("\n\n💾 NVMe Model Loader:")
    nvme_paths = ["/mnt/nvme0/models", "/mnt/nvme1/models"]
    loader = NVMeModelLoader(nvme_paths)
    
    # Registrar modelos
    loader.register_model("base_model", "model.safetensors", nvme_index=0)
    loader.register_model("voice_model", "voice.pt", nvme_index=1)
    
    print(f"Modelos registrados: {loader.list_models()}")
    
    print("\n✅ Ejemplo completado")
