"""
TERMINATOR REST API
===================

API REST completa para inferencia dirigida multimodal.
"""

from fastapi import FastAPI, HTTPException, File, UploadFile, BackgroundTasks, Depends
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse, StreamingResponse
from pydantic import BaseModel, Field
from typing import Optional, List, Dict, Any
import logging
import os
import sys
from pathlib import Path
import yaml
import asyncio

# Añadir paths
sys.path.insert(0, str(Path(__file__).parent.parent))

from inference.steerable_engine import SteerableInferenceEngine
from core.language_detector import MultimodalLanguageDetector
from audio.audio_processor import AudioProcessor
from vision.animation_3d import AnimationController

logger = logging.getLogger(__name__)

# Cargar configuración
config_path = Path(__file__).parent.parent / "config" / "config.yaml"
with open(config_path) as f:
    config = yaml.safe_load(f)

# Crear app
app = FastAPI(
    title=config['api']['title'],
    version=config['api']['version'],
    description=config['api']['description'],
    docs_url=config['api']['docs_url'],
    redoc_url=config['api']['redoc_url']
)

# CORS
if config['api']['cors']['enabled']:
    app.add_middleware(
        CORSMiddleware,
        allow_origins=config['api']['cors']['origins'],
        allow_credentials=True,
        allow_methods=config['api']['cors']['methods'],
        allow_headers=config['api']['cors']['headers'],
    )

# Estado global
class AppState:
    def __init__(self):
        self.inference_engine = None
        self.language_detector = MultimodalLanguageDetector()
        self.audio_processor = None
        self.animation_controller = AnimationController()
        self.initialized = False

state = AppState()


# Modelos Pydantic
class InferenceRequest(BaseModel):
    prompt: str = Field(..., description="Texto de entrada")
    max_length: int = Field(100, ge=1, le=4096)
    temperature: float = Field(0.7, ge=0.0, le=2.0)
    top_p: float = Field(0.9, ge=0.0, le=1.0)
    top_k: int = Field(50, ge=1, le=100)
    steering_config: Optional[Dict[str, float]] = Field(None, description="Configuración de steering")
    language: Optional[str] = Field(None, description="Idioma (auto-detecta si no se especifica)")


class InferenceResponse(BaseModel):
    generated_text: str
    language: str
    steering_applied: Dict[str, float]
    metadata: Dict[str, Any]


class LanguageDetectionRequest(BaseModel):
    text: str
    modality: str = Field("text", description="Modalidad: text, audio, auto")


class LanguageDetectionResponse(BaseModel):
    language: str
    confidence: float
    modality: str


class AudioSynthesisRequest(BaseModel):
    text: str
    voice_id: str = Field("default", description="ID de voz de ElevenLabs")
    language: str = Field("es", description="Idioma del texto")
    stability: float = Field(0.5, ge=0.0, le=1.0)
    similarity_boost: float = Field(0.75, ge=0.0, le=1.0)


class AnimationRequest(BaseModel):
    audio_path: Optional[str] = None
    text: Optional[str] = None
    animation_type: str = Field("lipsync", description="Tipo: lipsync, gesture, full")
    model_name: str = Field("default", description="Nombre del modelo 3D")


class HealthResponse(BaseModel):
    status: str
    version: str
    components: Dict[str, bool]


# Inicialización
@app.on_event("startup")
async def startup_event():
    """Inicializa componentes al arrancar"""
    logger.info("Iniciando TERMINATOR API...")
    
    try:
        # Inicializar audio processor si hay API key
        elevenlabs_key = os.getenv("ELEVENLABS_API_KEY")
        if elevenlabs_key:
            state.audio_processor = AudioProcessor(elevenlabs_api_key=elevenlabs_key)
            logger.info("Audio processor inicializado")
        else:
            logger.warning("ELEVENLABS_API_KEY no configurada, síntesis de audio deshabilitada")
        
        # Aquí se cargaría el modelo de inferencia
        # state.inference_engine = SteerableInferenceEngine(model, tokenizer)
        
        state.initialized = True
        logger.info("TERMINATOR API iniciada exitosamente")
    
    except Exception as e:
        logger.error(f"Error en startup: {e}")
        state.initialized = False


# Endpoints

@app.get("/", response_model=Dict)
async def root():
    """Endpoint raíz"""
    return {
        "name": "TERMINATOR API",
        "version": config['api']['version'],
        "status": "running" if state.initialized else "initializing",
        "docs": config['api']['docs_url']
    }


@app.get("/health", response_model=HealthResponse)
async def health_check():
    """Verifica el estado de salud del sistema"""
    return {
        "status": "healthy" if state.initialized else "initializing",
        "version": config['api']['version'],
        "components": {
            "inference_engine": state.inference_engine is not None,
            "language_detector": state.language_detector is not None,
            "audio_processor": state.audio_processor is not None,
            "animation_controller": state.animation_controller is not None,
        }
    }


@app.post("/api/v1/inference", response_model=InferenceResponse)
async def inference(request: InferenceRequest):
    """
    Realiza inferencia dirigida con el modelo
    """
    if not state.inference_engine:
        raise HTTPException(status_code=503, detail="Motor de inferencia no disponible")
    
    try:
        # Detectar idioma si no se especifica
        language = request.language
        if not language:
            lang_result = state.language_detector.detect_from_text(request.prompt)
            language = lang_result['language']
        
        # Generar texto
        generated = state.inference_engine.generate(
            prompt=request.prompt,
            max_length=request.max_length,
            temperature=request.temperature,
            top_p=request.top_p,
            top_k=request.top_k,
            steering_config=request.steering_config
        )
        
        return {
            "generated_text": generated,
            "language": language,
            "steering_applied": request.steering_config or {},
            "metadata": {
                "prompt_length": len(request.prompt),
                "output_length": len(generated),
                "temperature": request.temperature
            }
        }
    
    except Exception as e:
        logger.error(f"Error en inferencia: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/api/v1/language/detect", response_model=LanguageDetectionResponse)
async def detect_language(request: LanguageDetectionRequest):
    """
    Detecta el idioma de un texto o audio
    """
    try:
        result = state.language_detector.detect_auto(
            request.text,
            modality=request.modality
        )
        
        return {
            "language": result['language'],
            "confidence": result['confidence'],
            "modality": result['modality']
        }
    
    except Exception as e:
        logger.error(f"Error detectando idioma: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/api/v1/audio/synthesize")
async def synthesize_audio(request: AudioSynthesisRequest):
    """
    Sintetiza audio desde texto usando ElevenLabs
    """
    if not state.audio_processor:
        raise HTTPException(status_code=503, detail="Procesador de audio no disponible")
    
    try:
        audio_bytes = state.audio_processor.synthesize_speech(
            text=request.text,
            voice_id=request.voice_id,
            language=request.language,
            stability=request.stability,
            similarity_boost=request.similarity_boost
        )
        
        if not audio_bytes:
            raise HTTPException(status_code=500, detail="Error generando audio")
        
        return StreamingResponse(
            iter([audio_bytes]),
            media_type="audio/mpeg",
            headers={"Content-Disposition": "attachment; filename=synthesized.mp3"}
        )
    
    except Exception as e:
        logger.error(f"Error sintetizando audio: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/api/v1/audio/transcribe")
async def transcribe_audio(file: UploadFile = File(...)):
    """
    Transcribe audio a texto
    """
    if not state.audio_processor:
        raise HTTPException(status_code=503, detail="Procesador de audio no disponible")
    
    try:
        # Guardar archivo temporal
        temp_path = f"/tmp/{file.filename}"
        with open(temp_path, "wb") as f:
            content = await file.read()
            f.write(content)
        
        # Transcribir
        result = state.audio_processor.transcribe_audio(temp_path)
        
        # Limpiar
        os.remove(temp_path)
        
        return result
    
    except Exception as e:
        logger.error(f"Error transcribiendo audio: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/api/v1/animation/create")
async def create_animation(request: AnimationRequest):
    """
    Crea animación 3D sincronizada con audio
    """
    try:
        # Obtener o crear animator
        animator = state.animation_controller.get_animator(request.model_name)
        if not animator:
            animator = state.animation_controller.create_animator(request.model_name)
        
        # Sincronizar con audio si se proporciona
        if request.audio_path:
            result = state.animation_controller.sync_animation_with_audio(
                animator_name=request.model_name,
                audio_path=request.audio_path,
                text=request.text
            )
            
            return result
        
        return {"success": False, "error": "Se requiere audio_path"}
    
    except Exception as e:
        logger.error(f"Error creando animación: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/api/v1/steering/add")
async def add_steering_vector(
    name: str,
    layer_idx: int,
    strength: float = 1.0,
    file: UploadFile = File(...)
):
    """
    Añade un vector de steering al motor de inferencia
    """
    if not state.inference_engine:
        raise HTTPException(status_code=503, detail="Motor de inferencia no disponible")
    
    try:
        import numpy as np
        
        # Leer vector desde archivo
        content = await file.read()
        vector = np.frombuffer(content, dtype=np.float32)
        
        # Añadir al engine
        state.inference_engine.add_steering_vector(
            name=name,
            vector=vector,
            layer_idx=layer_idx,
            strength=strength
        )
        
        return {"success": True, "message": f"Vector '{name}' añadido"}
    
    except Exception as e:
        logger.error(f"Error añadiendo vector de steering: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/api/v1/steering/list")
async def list_steering_vectors():
    """
    Lista todos los vectores de steering disponibles
    """
    if not state.inference_engine:
        raise HTTPException(status_code=503, detail="Motor de inferencia no disponible")
    
    vectors = {}
    for name, sv in state.inference_engine.steering_vectors.items():
        vectors[name] = {
            "layer_idx": sv.layer_idx,
            "strength": sv.strength,
            "vector_shape": sv.vector.shape
        }
    
    return {"vectors": vectors}


@app.get("/api/v1/config")
async def get_config():
    """
    Obtiene la configuración actual del sistema
    """
    return {
        "server": config['server'],
        "gpu": config['gpu'],
        "inference": config['inference'],
        "language": config['language'],
        "audio": {k: v for k, v in config['audio'].items() if k != 'elevenlabs'}
    }


# Ejecutar servidor
if __name__ == "__main__":
    import uvicorn
    
    uvicorn.run(
        "main:app",
        host=config['server']['host'],
        port=config['server']['port'],
        workers=config['server']['workers'],
        reload=config['server']['reload'],
        log_level=config['server']['log_level']
    )
