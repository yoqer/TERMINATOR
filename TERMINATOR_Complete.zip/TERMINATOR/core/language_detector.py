"""
Language Detector
=================

Detecta automáticamente el idioma de texto o audio.
"""

import logging
from typing import Dict, List, Optional, Tuple
import re

logger = logging.getLogger(__name__)


class LanguageDetector:
    """Detector de idioma con soporte para múltiples métodos"""
    
    def __init__(self, supported_languages: Optional[List[str]] = None):
        self.supported_languages = supported_languages or ['es', 'en', 'fr', 'de', 'it', 'pt']
        self.default_language = 'es'
        
        # Intentar cargar modelo de detección
        self.detector = None
        self._load_detector()
    
    def _load_detector(self):
        """Carga el modelo de detección de idioma"""
        try:
            from langdetect import detect, detect_langs, LangDetectException
            self.detect_fn = detect
            self.detect_langs_fn = detect_langs
            self.exception_class = LangDetectException
            logger.info("Detector de idioma cargado: langdetect")
        except ImportError:
            logger.warning("langdetect no disponible, usando detector basado en reglas")
            self.detect_fn = self._rule_based_detect
            self.detect_langs_fn = self._rule_based_detect_langs
            self.exception_class = Exception
    
    def detect(self, text: str, confidence_threshold: float = 0.8) -> str:
        """
        Detecta el idioma de un texto
        
        Args:
            text: Texto a analizar
            confidence_threshold: Umbral de confianza mínimo
        
        Returns:
            Código ISO 639-1 del idioma detectado
        """
        if not text or len(text.strip()) < 3:
            logger.debug("Texto muy corto, usando idioma por defecto")
            return self.default_language
        
        try:
            detected = self.detect_fn(text)
            
            # Verificar si está en idiomas soportados
            if detected not in self.supported_languages:
                logger.debug(f"Idioma detectado '{detected}' no soportado, usando '{self.default_language}'")
                return self.default_language
            
            return detected
        
        except self.exception_class as e:
            logger.warning(f"Error detectando idioma: {e}, usando idioma por defecto")
            return self.default_language
    
    def detect_with_confidence(self, text: str) -> Tuple[str, float]:
        """
        Detecta el idioma con nivel de confianza
        
        Returns:
            Tupla (idioma, confianza)
        """
        if not text or len(text.strip()) < 3:
            return self.default_language, 0.5
        
        try:
            langs = self.detect_langs_fn(text)
            
            if langs:
                best_lang = langs[0]
                lang_code = best_lang.lang
                confidence = best_lang.prob
                
                if lang_code not in self.supported_languages:
                    return self.default_language, 0.5
                
                return lang_code, confidence
            
            return self.default_language, 0.5
        
        except self.exception_class as e:
            logger.warning(f"Error detectando idioma con confianza: {e}")
            return self.default_language, 0.5
    
    def detect_batch(self, texts: List[str]) -> List[str]:
        """Detecta idioma para múltiples textos"""
        return [self.detect(text) for text in texts]
    
    def _rule_based_detect(self, text: str) -> str:
        """Detector basado en reglas simples (fallback)"""
        text_lower = text.lower()
        
        # Palabras comunes por idioma
        patterns = {
            'es': r'\b(el|la|de|que|y|a|en|un|ser|se|no|haber|por|con|su|para|como|estar|tener)\b',
            'en': r'\b(the|be|to|of|and|a|in|that|have|i|it|for|not|on|with|he|as|you|do|at)\b',
            'fr': r'\b(le|de|un|être|et|à|il|avoir|ne|je|son|que|se|qui|ce|dans|en|du|elle|au)\b',
            'de': r'\b(der|die|und|in|den|von|zu|das|mit|sich|des|auf|für|ist|im|dem|nicht|ein|als)\b',
            'it': r'\b(il|di|e|la|a|per|che|in|un|è|non|si|da|con|le|dei|del|i|al|come)\b',
            'pt': r'\b(o|a|de|que|e|do|da|em|um|para|é|com|não|uma|os|no|se|na|por|mais)\b'
        }
        
        scores = {}
        for lang, pattern in patterns.items():
            matches = len(re.findall(pattern, text_lower))
            scores[lang] = matches
        
        if scores:
            best_lang = max(scores, key=scores.get)
            if scores[best_lang] > 0:
                return best_lang
        
        return self.default_language
    
    def _rule_based_detect_langs(self, text: str) -> List:
        """Versión con confianza del detector basado en reglas"""
        class LangProb:
            def __init__(self, lang, prob):
                self.lang = lang
                self.prob = prob
        
        detected = self._rule_based_detect(text)
        # Confianza arbitraria para fallback
        return [LangProb(detected, 0.7)]


class MultimodalLanguageDetector:
    """Detector de idioma para múltiples modalidades"""
    
    def __init__(self):
        self.text_detector = LanguageDetector()
        self.audio_detector = None
        self._load_audio_detector()
    
    def _load_audio_detector(self):
        """Carga detector de idioma para audio"""
        try:
            # Aquí se cargaría un modelo de detección de idioma en audio
            # Por ejemplo, usando Whisper o un modelo específico
            logger.info("Detector de idioma de audio inicializado")
        except Exception as e:
            logger.warning(f"No se pudo cargar detector de audio: {e}")
    
    def detect_from_text(self, text: str) -> Dict:
        """Detecta idioma desde texto"""
        lang, confidence = self.text_detector.detect_with_confidence(text)
        
        return {
            'language': lang,
            'confidence': confidence,
            'modality': 'text'
        }
    
    def detect_from_audio(self, audio_path: str) -> Dict:
        """Detecta idioma desde audio"""
        # Primero transcribir el audio
        try:
            # Aquí se usaría Whisper u otro modelo de transcripción
            # transcription = transcribe_audio(audio_path)
            # lang = transcription.get('language', 'es')
            
            # Por ahora, retornar español por defecto
            return {
                'language': 'es',
                'confidence': 0.8,
                'modality': 'audio',
                'note': 'Audio detection requires Whisper or similar model'
            }
        
        except Exception as e:
            logger.error(f"Error detectando idioma de audio: {e}")
            return {
                'language': 'es',
                'confidence': 0.5,
                'modality': 'audio',
                'error': str(e)
            }
    
    def detect_auto(self, input_data: str, modality: str = 'auto') -> Dict:
        """
        Detecta idioma automáticamente según la modalidad
        
        Args:
            input_data: Texto o ruta a archivo de audio
            modality: 'text', 'audio', o 'auto'
        
        Returns:
            Dict con idioma detectado y metadata
        """
        if modality == 'text' or (modality == 'auto' and isinstance(input_data, str) and len(input_data) < 1000):
            return self.detect_from_text(input_data)
        elif modality == 'audio' or (modality == 'auto' and input_data.endswith(('.wav', '.mp3', '.ogg', '.flac'))):
            return self.detect_from_audio(input_data)
        else:
            # Por defecto, asumir texto
            return self.detect_from_text(input_data)


# Ejemplo de uso
if __name__ == "__main__":
    print("=" * 70)
    print("LANGUAGE DETECTOR - EJEMPLO")
    print("=" * 70)
    
    # Crear detector
    detector = LanguageDetector()
    
    # Textos de ejemplo
    texts = {
        'es': "Hola, ¿cómo estás? Este es un texto en español.",
        'en': "Hello, how are you? This is a text in English.",
        'fr': "Bonjour, comment allez-vous? Ceci est un texte en français.",
        'de': "Hallo, wie geht es dir? Dies ist ein Text auf Deutsch.",
    }
    
    print("\n📝 Detectando idiomas:")
    for expected_lang, text in texts.items():
        detected, confidence = detector.detect_with_confidence(text)
        status = "✅" if detected == expected_lang else "❌"
        print(f"{status} Esperado: {expected_lang}, Detectado: {detected} (confianza: {confidence:.2f})")
        print(f"   Texto: {text[:50]}...")
    
    # Detector multimodal
    print("\n\n🌐 Detector Multimodal:")
    multi_detector = MultimodalLanguageDetector()
    
    result = multi_detector.detect_auto("Este es un texto de prueba en español")
    print(f"Resultado: {result}")
    
    print("\n✅ Ejemplo completado")
