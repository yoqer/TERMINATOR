#!/bin/bash
# TERMINATOR - Quick Start Script

set -e

echo "=================================="
echo "🤖 TERMINATOR Framework"
echo "=================================="
echo ""

# Colors
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m' # No Color

# Verificar Python
echo -e "${YELLOW}📦 Verificando Python...${NC}"
if ! command -v python3 &> /dev/null; then
    echo -e "${RED}❌ Python 3 no encontrado${NC}"
    exit 1
fi
echo -e "${GREEN}✅ Python encontrado: $(python3 --version)${NC}"

# Verificar CUDA
echo -e "${YELLOW}🎮 Verificando CUDA...${NC}"
if command -v nvidia-smi &> /dev/null; then
    echo -e "${GREEN}✅ CUDA disponible${NC}"
    nvidia-smi --query-gpu=index,name,memory.total --format=csv,noheader
else
    echo -e "${YELLOW}⚠️  CUDA no disponible (modo CPU)${NC}"
fi

# Crear entorno virtual si no existe
if [ ! -d "venv" ]; then
    echo -e "${YELLOW}🔧 Creando entorno virtual...${NC}"
    python3 -m venv venv
    echo -e "${GREEN}✅ Entorno virtual creado${NC}"
fi

# Activar entorno
echo -e "${YELLOW}🔄 Activando entorno virtual...${NC}"
source venv/bin/activate

# Instalar dependencias
echo -e "${YELLOW}📥 Instalando dependencias...${NC}"
pip install --upgrade pip -q
pip install -r requirements.txt -q
echo -e "${GREEN}✅ Dependencias instaladas${NC}"

# Verificar variables de entorno
if [ ! -f ".env" ]; then
    echo -e "${YELLOW}⚙️  Creando archivo .env...${NC}"
    cat > .env << 'EOF'
# ElevenLabs API (opcional)
ELEVENLABS_API_KEY=

# Servidor
HOST=0.0.0.0
PORT=8000

# GPUs
CUDA_VISIBLE_DEVICES=0

# Logging
LOG_LEVEL=INFO
EOF
    echo -e "${GREEN}✅ Archivo .env creado${NC}"
    echo -e "${YELLOW}⚠️  Edita .env para configurar ELEVENLABS_API_KEY${NC}"
fi

# Cargar variables
export $(cat .env | grep -v '^#' | xargs)

# Crear directorios
echo -e "${YELLOW}📁 Creando directorios...${NC}"
mkdir -p logs
mkdir -p models
mkdir -p cache
echo -e "${GREEN}✅ Directorios creados${NC}"

# Iniciar servidor
echo ""
echo -e "${GREEN}🚀 Iniciando TERMINATOR API...${NC}"
echo ""
echo "📍 Endpoints:"
echo "   - API: http://localhost:${PORT}"
echo "   - Docs: http://localhost:${PORT}/docs"
echo "   - Health: http://localhost:${PORT}/health"
echo ""
echo "Press Ctrl+C to stop"
echo ""

# Ejecutar servidor
python -m uvicorn api.main:app \
    --host ${HOST} \
    --port ${PORT} \
    --log-level ${LOG_LEVEL,,}
