"""
Audio Processor
===============

Procesamiento de audio con integración de ElevenLabs para síntesis de voz.
"""

import os
import logging
from typing import Optional, Dict, List, Union
from pathlib import Path
import requests
import json

logger = logging.getLogger(__name__)


class ElevenLabsClient:
    """Cliente para la API de ElevenLabs"""
    
    def __init__(
        self,
        api_key: Optional[str] = None,
        model_id: str = "eleven_multilingual_v2"
    ):
        self.api_key = api_key or os.getenv("ELEVENLABS_API_KEY")
        if not self.api_key:
            raise ValueError("ELEVENLABS_API_KEY no configurada")
        
        self.model_id = model_id
        self.base_url = "https://api.elevenlabs.io/v1"
        self.headers = {
            "Accept": "audio/mpeg",
            "Content-Type": "application/json",
            "xi-api-key": self.api_key
        }
    
    def get_voices(self) -> List[Dict]:
        """Obtiene lista de voces disponibles"""
        url = f"{self.base_url}/voices"
        
        try:
            response = requests.get(url, headers=self.headers)
            response.raise_for_status()
            
            data = response.json()
            voices = data.get('voices', [])
            
            logger.info(f"Obtenidas {len(voices)} voces disponibles")
            return voices
        
        except requests.exceptions.RequestException as e:
            logger.error(f"Error obteniendo voces: {e}")
            return []
    
    def text_to_speech(
        self,
        text: str,
        voice_id: str = "default",
        output_path: Optional[str] = None,
        stability: float = 0.5,
        similarity_boost: float = 0.75,
        style: float = 0.0,
        use_speaker_boost: bool = True
    ) -> Optional[bytes]:
        """
        Convierte texto a audio usando ElevenLabs
        
        Args:
            text: Texto a sintetizar
            voice_id: ID de la voz a usar
            output_path: Ruta donde guardar el audio (opcional)
            stability: Estabilidad de la voz (0-1)
            similarity_boost: Boost de similitud (0-1)
            style: Estilo de la voz (0-1)
            use_speaker_boost: Usar speaker boost
        
        Returns:
            Bytes del audio generado o None si hay error
        """
        url = f"{self.base_url}/text-to-speech/{voice_id}"
        
        payload = {
            "text": text,
            "model_id": self.model_id,
            "voice_settings": {
                "stability": stability,
                "similarity_boost": similarity_boost,
                "style": style,
                "use_speaker_boost": use_speaker_boost
            }
        }
        
        try:
            logger.info(f"Generando audio para texto de {len(text)} caracteres")
            
            response = requests.post(
                url,
                json=payload,
                headers=self.headers,
                timeout=60
            )
            response.raise_for_status()
            
            audio_bytes = response.content
            
            # Guardar si se especifica ruta
            if output_path:
                Path(output_path).parent.mkdir(parents=True, exist_ok=True)
                with open(output_path, 'wb') as f:
                    f.write(audio_bytes)
                logger.info(f"Audio guardado en {output_path}")
            
            return audio_bytes
        
        except requests.exceptions.RequestException as e:
            logger.error(f"Error generando audio: {e}")
            return None
    
    def text_to_speech_stream(
        self,
        text: str,
        voice_id: str = "default",
        **kwargs
    ):
        """Genera audio en streaming"""
        url = f"{self.base_url}/text-to-speech/{voice_id}/stream"
        
        payload = {
            "text": text,
            "model_id": self.model_id,
            "voice_settings": {
                "stability": kwargs.get('stability', 0.5),
                "similarity_boost": kwargs.get('similarity_boost', 0.75),
                "style": kwargs.get('style', 0.0),
                "use_speaker_boost": kwargs.get('use_speaker_boost', True)
            }
        }
        
        try:
            response = requests.post(
                url,
                json=payload,
                headers=self.headers,
                stream=True,
                timeout=60
            )
            response.raise_for_status()
            
            for chunk in response.iter_content(chunk_size=1024):
                if chunk:
                    yield chunk
        
        except requests.exceptions.RequestException as e:
            logger.error(f"Error en streaming de audio: {e}")
            yield None


class AudioProcessor:
    """Procesador de audio con múltiples capacidades"""
    
    def __init__(
        self,
        elevenlabs_api_key: Optional[str] = None,
        cache_dir: str = "/tmp/audio_cache"
    ):
        self.elevenlabs = ElevenLabsClient(elevenlabs_api_key) if elevenlabs_api_key else None
        self.cache_dir = Path(cache_dir)
        self.cache_dir.mkdir(parents=True, exist_ok=True)
        
        # Cargar modelo de transcripción si está disponible
        self.transcription_model = None
        self._load_transcription_model()
    
    def _load_transcription_model(self):
        """Carga modelo de transcripción (Whisper)"""
        try:
            import whisper
            self.transcription_model = whisper.load_model("base")
            logger.info("Modelo de transcripción Whisper cargado")
        except ImportError:
            logger.warning("Whisper no disponible, transcripción deshabilitada")
        except Exception as e:
            logger.error(f"Error cargando Whisper: {e}")
    
    def transcribe_audio(
        self,
        audio_path: str,
        language: Optional[str] = None,
        task: str = "transcribe"
    ) -> Dict:
        """
        Transcribe audio a texto
        
        Args:
            audio_path: Ruta al archivo de audio
            language: Idioma del audio (opcional, auto-detecta)
            task: 'transcribe' o 'translate'
        
        Returns:
            Dict con transcripción y metadata
        """
        if not self.transcription_model:
            return {
                'error': 'Modelo de transcripción no disponible',
                'text': ''
            }
        
        try:
            logger.info(f"Transcribiendo audio: {audio_path}")
            
            result = self.transcription_model.transcribe(
                audio_path,
                language=language,
                task=task
            )
            
            return {
                'text': result['text'],
                'language': result.get('language', 'unknown'),
                'segments': result.get('segments', []),
                'task': task
            }
        
        except Exception as e:
            logger.error(f"Error transcribiendo audio: {e}")
            return {
                'error': str(e),
                'text': ''
            }
    
    def synthesize_speech(
        self,
        text: str,
        voice_id: str = "default",
        language: str = "es",
        output_path: Optional[str] = None,
        **kwargs
    ) -> Optional[bytes]:
        """
        Sintetiza voz desde texto
        
        Args:
            text: Texto a sintetizar
            voice_id: ID de voz de ElevenLabs
            language: Idioma del texto
            output_path: Donde guardar el audio
            **kwargs: Parámetros adicionales para ElevenLabs
        
        Returns:
            Bytes del audio o None
        """
        if not self.elevenlabs:
            logger.error("Cliente ElevenLabs no inicializado")
            return None
        
        # Generar nombre de cache si no se especifica output
        if not output_path:
            import hashlib
            text_hash = hashlib.md5(text.encode()).hexdigest()
            output_path = str(self.cache_dir / f"{text_hash}_{voice_id}.mp3")
        
        # Verificar cache
        if os.path.exists(output_path):
            logger.info(f"Audio encontrado en cache: {output_path}")
            with open(output_path, 'rb') as f:
                return f.read()
        
        # Generar nuevo audio
        audio_bytes = self.elevenlabs.text_to_speech(
            text=text,
            voice_id=voice_id,
            output_path=output_path,
            **kwargs
        )
        
        return audio_bytes
    
    def process_audio_file(
        self,
        audio_path: str,
        operations: List[str] = None
    ) -> Dict:
        """
        Procesa un archivo de audio con múltiples operaciones
        
        Args:
            audio_path: Ruta al audio
            operations: Lista de operaciones a realizar
                       ['transcribe', 'detect_language', 'extract_features']
        
        Returns:
            Dict con resultados de las operaciones
        """
        operations = operations or ['transcribe']
        results = {}
        
        if 'transcribe' in operations:
            results['transcription'] = self.transcribe_audio(audio_path)
        
        if 'detect_language' in operations:
            # Usar transcripción para detectar idioma
            if 'transcription' not in results:
                results['transcription'] = self.transcribe_audio(audio_path)
            results['language'] = results['transcription'].get('language', 'unknown')
        
        if 'extract_features' in operations:
            results['features'] = self._extract_audio_features(audio_path)
        
        return results
    
    def _extract_audio_features(self, audio_path: str) -> Dict:
        """Extrae características del audio"""
        try:
            import librosa
            
            # Cargar audio
            y, sr = librosa.load(audio_path)
            
            # Extraer características
            features = {
                'duration': float(librosa.get_duration(y=y, sr=sr)),
                'sample_rate': sr,
                'tempo': float(librosa.beat.tempo(y=y, sr=sr)[0]),
                'zero_crossing_rate': float(librosa.feature.zero_crossing_rate(y)[0].mean()),
            }
            
            return features
        
        except ImportError:
            logger.warning("librosa no disponible para extracción de características")
            return {}
        except Exception as e:
            logger.error(f"Error extrayendo características: {e}")
            return {}
    
    def batch_synthesize(
        self,
        texts: List[str],
        voice_id: str = "default",
        output_dir: Optional[str] = None
    ) -> List[str]:
        """Sintetiza múltiples textos en batch"""
        output_dir = Path(output_dir) if output_dir else self.cache_dir
        output_dir.mkdir(parents=True, exist_ok=True)
        
        output_paths = []
        
        for i, text in enumerate(texts):
            output_path = str(output_dir / f"audio_{i:04d}.mp3")
            
            audio_bytes = self.synthesize_speech(
                text=text,
                voice_id=voice_id,
                output_path=output_path
            )
            
            if audio_bytes:
                output_paths.append(output_path)
            else:
                output_paths.append(None)
        
        return output_paths


# Ejemplo de uso
if __name__ == "__main__":
    print("=" * 70)
    print("AUDIO PROCESSOR - EJEMPLO")
    print("=" * 70)
    
    # Crear procesador (requiere API key de ElevenLabs)
    # processor = AudioProcessor(elevenlabs_api_key="tu_api_key")
    
    print("\n1. Síntesis de voz:")
    print("   Texto: 'Hola, este es un ejemplo de síntesis de voz'")
    # audio = processor.synthesize_speech(
    #     text="Hola, este es un ejemplo de síntesis de voz",
    #     voice_id="default",
    #     output_path="ejemplo.mp3"
    # )
    
    print("\n2. Transcripción de audio:")
    # result = processor.transcribe_audio("ejemplo.mp3")
    # print(f"   Transcripción: {result.get('text', '')}")
    # print(f"   Idioma: {result.get('language', 'unknown')}")
    
    print("\n3. Procesamiento completo:")
    # results = processor.process_audio_file(
    #     "ejemplo.mp3",
    #     operations=['transcribe', 'detect_language', 'extract_features']
    # )
    
    print("\n✅ Ejemplo completado")
    print("\nNota: Para ejecutar este ejemplo, necesitas:")
    print("  - API key de ElevenLabs")
    print("  - pip install openai-whisper librosa")
