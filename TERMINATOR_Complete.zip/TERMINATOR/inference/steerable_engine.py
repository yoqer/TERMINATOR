"""
Steerable Inference Engine
===========================

Motor de inferencia dirigida que permite controlar la generación
mediante vectores de steering.
"""

import torch
import torch.nn.functional as F
import numpy as np
from typing import Dict, List, Optional, Tuple, Any
from pathlib import Path
import logging

logger = logging.getLogger(__name__)


class SteeringVector:
    """Representa un vector de steering para dirigir la inferencia"""
    
    def __init__(self, vector: np.ndarray, layer_idx: int, strength: float = 1.0):
        self.vector = vector
        self.layer_idx = layer_idx
        self.strength = strength
    
    def apply(self, hidden_states: torch.Tensor) -> torch.Tensor:
        """Aplica el vector de steering a los hidden states"""
        device = hidden_states.device
        steering_tensor = torch.from_numpy(self.vector).to(device).float()
        
        # Normalizar y aplicar con strength
        steering_tensor = F.normalize(steering_tensor, dim=-1) * self.strength
        
        # Sumar al hidden state
        return hidden_states + steering_tensor


class SteerableInferenceEngine:
    """Motor de inferencia con capacidad de steering"""
    
    def __init__(
        self,
        model,
        tokenizer,
        device: str = "cuda",
        steering_vectors_path: Optional[str] = None
    ):
        self.model = model
        self.tokenizer = tokenizer
        self.device = device
        self.steering_vectors: Dict[str, SteeringVector] = {}
        
        if steering_vectors_path:
            self.load_steering_vectors(steering_vectors_path)
        
        # Hooks para interceptar capas
        self.hooks = []
        self.register_hooks()
    
    def load_steering_vectors(self, path: str):
        """Carga vectores de steering desde archivo"""
        logger.info(f"Cargando vectores de steering desde {path}")
        
        data = np.load(path, allow_pickle=True)
        
        for name in data.files:
            vector_data = data[name].item()
            self.steering_vectors[name] = SteeringVector(
                vector=vector_data['vector'],
                layer_idx=vector_data['layer_idx'],
                strength=vector_data.get('strength', 1.0)
            )
        
        logger.info(f"Cargados {len(self.steering_vectors)} vectores de steering")
    
    def save_steering_vectors(self, path: str):
        """Guarda vectores de steering a archivo"""
        vectors_dict = {}
        
        for name, sv in self.steering_vectors.items():
            vectors_dict[name] = {
                'vector': sv.vector,
                'layer_idx': sv.layer_idx,
                'strength': sv.strength
            }
        
        np.savez(path, **vectors_dict)
        logger.info(f"Vectores de steering guardados en {path}")
    
    def add_steering_vector(
        self,
        name: str,
        vector: np.ndarray,
        layer_idx: int,
        strength: float = 1.0
    ):
        """Añade un nuevo vector de steering"""
        self.steering_vectors[name] = SteeringVector(vector, layer_idx, strength)
        logger.debug(f"Vector de steering '{name}' añadido en capa {layer_idx}")
    
    def remove_steering_vector(self, name: str):
        """Elimina un vector de steering"""
        if name in self.steering_vectors:
            del self.steering_vectors[name]
            logger.debug(f"Vector de steering '{name}' eliminado")
    
    def set_steering_strength(self, name: str, strength: float):
        """Ajusta la fuerza de un vector de steering"""
        if name in self.steering_vectors:
            self.steering_vectors[name].strength = strength
    
    def register_hooks(self):
        """Registra hooks en las capas del modelo para aplicar steering"""
        def create_hook(layer_idx: int):
            def hook(module, input, output):
                # Aplicar todos los vectores de steering para esta capa
                modified_output = output
                
                for name, sv in self.steering_vectors.items():
                    if sv.layer_idx == layer_idx:
                        if isinstance(modified_output, tuple):
                            hidden_states = modified_output[0]
                            hidden_states = sv.apply(hidden_states)
                            modified_output = (hidden_states,) + modified_output[1:]
                        else:
                            modified_output = sv.apply(modified_output)
                
                return modified_output
            
            return hook
        
        # Registrar hooks en todas las capas del transformer
        if hasattr(self.model, 'transformer'):
            layers = self.model.transformer.h
        elif hasattr(self.model, 'model'):
            layers = self.model.model.layers
        else:
            logger.warning("No se pudieron encontrar las capas del modelo")
            return
        
        for idx, layer in enumerate(layers):
            handle = layer.register_forward_hook(create_hook(idx))
            self.hooks.append(handle)
    
    def remove_hooks(self):
        """Elimina todos los hooks registrados"""
        for hook in self.hooks:
            hook.remove()
        self.hooks = []
    
    @torch.no_grad()
    def generate(
        self,
        prompt: str,
        max_length: int = 100,
        temperature: float = 0.7,
        top_p: float = 0.9,
        top_k: int = 50,
        repetition_penalty: float = 1.1,
        steering_config: Optional[Dict[str, float]] = None,
        **kwargs
    ) -> str:
        """
        Genera texto con steering dirigido
        
        Args:
            prompt: Texto de entrada
            max_length: Longitud máxima de generación
            temperature: Temperatura de sampling
            top_p: Nucleus sampling
            top_k: Top-k sampling
            repetition_penalty: Penalización por repetición
            steering_config: Dict con nombres de vectores y sus strengths
            
        Returns:
            Texto generado
        """
        # Aplicar configuración de steering temporal
        original_strengths = {}
        if steering_config:
            for name, strength in steering_config.items():
                if name in self.steering_vectors:
                    original_strengths[name] = self.steering_vectors[name].strength
                    self.steering_vectors[name].strength = strength
        
        try:
            # Tokenizar
            inputs = self.tokenizer(prompt, return_tensors="pt").to(self.device)
            
            # Generar
            outputs = self.model.generate(
                **inputs,
                max_length=max_length,
                temperature=temperature,
                top_p=top_p,
                top_k=top_k,
                repetition_penalty=repetition_penalty,
                do_sample=True,
                pad_token_id=self.tokenizer.eos_token_id,
                **kwargs
            )
            
            # Decodificar
            generated_text = self.tokenizer.decode(outputs[0], skip_special_tokens=True)
            
            # Remover el prompt de la salida
            if generated_text.startswith(prompt):
                generated_text = generated_text[len(prompt):].strip()
            
            return generated_text
        
        finally:
            # Restaurar strengths originales
            for name, strength in original_strengths.items():
                self.steering_vectors[name].strength = strength
    
    @torch.no_grad()
    def generate_batch(
        self,
        prompts: List[str],
        max_length: int = 100,
        **kwargs
    ) -> List[str]:
        """Genera texto para múltiples prompts en batch"""
        inputs = self.tokenizer(
            prompts,
            return_tensors="pt",
            padding=True,
            truncation=True
        ).to(self.device)
        
        outputs = self.model.generate(
            **inputs,
            max_length=max_length,
            pad_token_id=self.tokenizer.eos_token_id,
            **kwargs
        )
        
        generated_texts = [
            self.tokenizer.decode(output, skip_special_tokens=True)
            for output in outputs
        ]
        
        return generated_texts
    
    def extract_steering_vector(
        self,
        positive_prompts: List[str],
        negative_prompts: List[str],
        layer_idx: int,
        name: str
    ) -> SteeringVector:
        """
        Extrae un vector de steering comparando prompts positivos y negativos
        
        Args:
            positive_prompts: Prompts que representan el comportamiento deseado
            negative_prompts: Prompts que representan el comportamiento a evitar
            layer_idx: Índice de la capa donde extraer el vector
            name: Nombre para el vector
        
        Returns:
            Vector de steering extraído
        """
        logger.info(f"Extrayendo vector de steering '{name}' en capa {layer_idx}")
        
        # Obtener activaciones para prompts positivos
        positive_activations = []
        for prompt in positive_prompts:
            acts = self._get_layer_activations(prompt, layer_idx)
            positive_activations.append(acts)
        
        # Obtener activaciones para prompts negativos
        negative_activations = []
        for prompt in negative_prompts:
            acts = self._get_layer_activations(prompt, layer_idx)
            negative_activations.append(acts)
        
        # Calcular diferencia promedio
        pos_mean = np.mean(positive_activations, axis=0)
        neg_mean = np.mean(negative_activations, axis=0)
        
        steering_vector = pos_mean - neg_mean
        
        # Crear y guardar el vector
        sv = SteeringVector(steering_vector, layer_idx)
        self.steering_vectors[name] = sv
        
        logger.info(f"Vector de steering '{name}' extraído exitosamente")
        
        return sv
    
    def _get_layer_activations(self, prompt: str, layer_idx: int) -> np.ndarray:
        """Obtiene las activaciones de una capa específica"""
        activations = []
        
        def hook(module, input, output):
            if isinstance(output, tuple):
                activations.append(output[0].detach().cpu().numpy())
            else:
                activations.append(output.detach().cpu().numpy())
        
        # Registrar hook temporal
        if hasattr(self.model, 'transformer'):
            layer = self.model.transformer.h[layer_idx]
        elif hasattr(self.model, 'model'):
            layer = self.model.model.layers[layer_idx]
        else:
            raise ValueError("No se pudo acceder a las capas del modelo")
        
        handle = layer.register_forward_hook(hook)
        
        try:
            # Forward pass
            inputs = self.tokenizer(prompt, return_tensors="pt").to(self.device)
            with torch.no_grad():
                self.model(**inputs)
            
            # Obtener activaciones (promedio sobre secuencia)
            acts = activations[0]
            acts = np.mean(acts, axis=1)  # Promedio sobre tokens
            
            return acts.squeeze()
        
        finally:
            handle.remove()
    
    def __del__(self):
        """Limpieza al destruir el objeto"""
        self.remove_hooks()


# Ejemplo de uso
if __name__ == "__main__":
    # Este es un ejemplo conceptual
    # En producción, cargarías tu modelo real
    
    print("=" * 70)
    print("STEERABLE INFERENCE ENGINE - EJEMPLO")
    print("=" * 70)
    
    # Simular carga de modelo
    print("\n1. Cargando modelo...")
    # model = AutoModelForCausalLM.from_pretrained("model_path")
    # tokenizer = AutoTokenizer.from_pretrained("model_path")
    
    # Crear engine
    # engine = SteerableInferenceEngine(model, tokenizer)
    
    # Añadir vectores de steering
    print("\n2. Añadiendo vectores de steering...")
    # engine.add_steering_vector(
    #     name="formal",
    #     vector=np.random.randn(4096),  # Dimensión del modelo
    #     layer_idx=15,
    #     strength=1.0
    # )
    
    # Generar con steering
    print("\n3. Generando con steering...")
    # output = engine.generate(
    #     prompt="Explica la teoría de la relatividad",
    #     steering_config={"formal": 1.5}
    # )
    
    print("\n✅ Ejemplo completado")
